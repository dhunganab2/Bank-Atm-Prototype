//
// Created by Bijay Dhungana on 2/6/25.
//

#ifndef PROG2_H
#define PROG2_H



class prog2 {

};



#endif //PROG2_H
